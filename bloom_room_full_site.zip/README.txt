BLOOM ROOM — готовый архив сайта

Как открыть:
1. Распакуйте архив.
2. Откройте файл index.html в браузере.

Что внутри:
- index.html — структура сайта
- style.css — дизайн
- script.js — меню и отправка заявки в WhatsApp
- assets — фото мебели и QR-коды

Контакты на сайте:
Телефон: 8 922 104-94-56
WhatsApp: https://wa.me/79221049456
Telegram: https://t.me/MARIIA_SERGEEVNAAA

Чтобы получить настоящую ссылку на сайт, загрузите эти файлы на Netlify, GitHub Pages, Beget, Timeweb или другой хостинг.
